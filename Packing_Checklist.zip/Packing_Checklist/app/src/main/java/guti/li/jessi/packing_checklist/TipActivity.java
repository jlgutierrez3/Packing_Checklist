package guti.li.jessi.packing_checklist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Jessi on 3/4/2018.
 */



public class TipActivity extends Activity{
    /************************************************************************************************
     * Variables
     ***********************************************************************************************/
    private Button okButton;


    //onCreate
    @Override
//    When decorating a method call parameter, this denotes that the parameter can
//    legitimately be null and the method will gracefully deal with it. Typically
//    used on optional parameters.
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip);

        Bundle extras = getIntent().getExtras();

        TextView example = (TextView)findViewById(R.id.textView_hint);
        example.setText(extras.getString("Message"));

        okButton = (Button) findViewById(R.id.back_button);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(TipActivity.RESULT_OK);
            }
        });
    }
}
